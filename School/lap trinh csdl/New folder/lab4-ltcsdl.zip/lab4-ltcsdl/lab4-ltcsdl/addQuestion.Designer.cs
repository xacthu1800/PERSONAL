﻿namespace lab4_ltcsdl
{
    partial class addQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textSet = new System.Windows.Forms.TextBox();
            this.questionNumber = new System.Windows.Forms.Label();
            this.Question = new System.Windows.Forms.Label();
            this.textQuestion = new System.Windows.Forms.TextBox();
            this.textOption1 = new System.Windows.Forms.TextBox();
            this.labelOption1 = new System.Windows.Forms.Label();
            this.textOption2 = new System.Windows.Forms.TextBox();
            this.labelOption2 = new System.Windows.Forms.Label();
            this.textOption3 = new System.Windows.Forms.TextBox();
            this.labelOption3 = new System.Windows.Forms.Label();
            this.textOption4 = new System.Windows.Forms.TextBox();
            this.labelOption4 = new System.Windows.Forms.Label();
            this.textAnswer = new System.Windows.Forms.TextBox();
            this.labelAnswer = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(28, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(253, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Add question";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(34, 113);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Set";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(413, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Qusetion No";
            // 
            // textSet
            // 
            this.textSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textSet.Location = new System.Drawing.Point(39, 157);
            this.textSet.Name = "textSet";
            this.textSet.Size = new System.Drawing.Size(301, 34);
            this.textSet.TabIndex = 3;
            this.textSet.TextChanged += new System.EventHandler(this.textSet_TextChanged);
            this.textSet.KeyUp += new System.Windows.Forms.KeyEventHandler(this.textSet_KeyUp);
            // 
            // questionNumber
            // 
            this.questionNumber.AutoSize = true;
            this.questionNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.questionNumber.Location = new System.Drawing.Point(472, 145);
            this.questionNumber.Name = "questionNumber";
            this.questionNumber.Size = new System.Drawing.Size(0, 29);
            this.questionNumber.TabIndex = 4;
            // 
            // Question
            // 
            this.Question.AutoSize = true;
            this.Question.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Question.Location = new System.Drawing.Point(33, 219);
            this.Question.Name = "Question";
            this.Question.Size = new System.Drawing.Size(129, 32);
            this.Question.TabIndex = 5;
            this.Question.Text = "Question";
            // 
            // textQuestion
            // 
            this.textQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textQuestion.Location = new System.Drawing.Point(36, 265);
            this.textQuestion.Name = "textQuestion";
            this.textQuestion.Size = new System.Drawing.Size(1136, 38);
            this.textQuestion.TabIndex = 6;
            // 
            // textOption1
            // 
            this.textOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textOption1.Location = new System.Drawing.Point(51, 378);
            this.textOption1.Name = "textOption1";
            this.textOption1.Size = new System.Drawing.Size(510, 38);
            this.textOption1.TabIndex = 8;
            // 
            // labelOption1
            // 
            this.labelOption1.AutoSize = true;
            this.labelOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption1.Location = new System.Drawing.Point(36, 324);
            this.labelOption1.Name = "labelOption1";
            this.labelOption1.Size = new System.Drawing.Size(122, 32);
            this.labelOption1.TabIndex = 7;
            this.labelOption1.Text = "Option 1";
            // 
            // textOption2
            // 
            this.textOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textOption2.Location = new System.Drawing.Point(678, 378);
            this.textOption2.Name = "textOption2";
            this.textOption2.Size = new System.Drawing.Size(533, 38);
            this.textOption2.TabIndex = 10;
            // 
            // labelOption2
            // 
            this.labelOption2.AutoSize = true;
            this.labelOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption2.Location = new System.Drawing.Point(675, 324);
            this.labelOption2.Name = "labelOption2";
            this.labelOption2.Size = new System.Drawing.Size(122, 32);
            this.labelOption2.TabIndex = 9;
            this.labelOption2.Text = "Option 2";
            // 
            // textOption3
            // 
            this.textOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textOption3.Location = new System.Drawing.Point(39, 515);
            this.textOption3.Name = "textOption3";
            this.textOption3.Size = new System.Drawing.Size(522, 38);
            this.textOption3.TabIndex = 12;
            // 
            // labelOption3
            // 
            this.labelOption3.AutoSize = true;
            this.labelOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption3.Location = new System.Drawing.Point(36, 469);
            this.labelOption3.Name = "labelOption3";
            this.labelOption3.Size = new System.Drawing.Size(122, 32);
            this.labelOption3.TabIndex = 11;
            this.labelOption3.Text = "Option 3";
            // 
            // textOption4
            // 
            this.textOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textOption4.Location = new System.Drawing.Point(678, 515);
            this.textOption4.Name = "textOption4";
            this.textOption4.Size = new System.Drawing.Size(533, 38);
            this.textOption4.TabIndex = 14;
            // 
            // labelOption4
            // 
            this.labelOption4.AutoSize = true;
            this.labelOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption4.Location = new System.Drawing.Point(675, 469);
            this.labelOption4.Name = "labelOption4";
            this.labelOption4.Size = new System.Drawing.Size(106, 32);
            this.labelOption4.TabIndex = 13;
            this.labelOption4.Text = "Optin 4";
            // 
            // textAnswer
            // 
            this.textAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.textAnswer.Location = new System.Drawing.Point(39, 661);
            this.textAnswer.Name = "textAnswer";
            this.textAnswer.Size = new System.Drawing.Size(522, 38);
            this.textAnswer.TabIndex = 16;
            // 
            // labelAnswer
            // 
            this.labelAnswer.AutoSize = true;
            this.labelAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelAnswer.Location = new System.Drawing.Point(36, 615);
            this.labelAnswer.Name = "labelAnswer";
            this.labelAnswer.Size = new System.Drawing.Size(108, 32);
            this.labelAnswer.TabIndex = 15;
            this.labelAnswer.Text = "Answer";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(713, 589);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(181, 58);
            this.button1.TabIndex = 17;
            this.button1.Text = "Next";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(991, 589);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 58);
            this.button2.TabIndex = 18;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button3.Location = new System.Drawing.Point(790, 661);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(317, 58);
            this.button3.TabIndex = 19;
            this.button3.Text = "Finish";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1347, 31);
            this.toolStrip1.TabIndex = 28;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(117, 28);
            this.toolStripLabel1.Text = "UpdateQuestion";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click);
            // 
            // addQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 783);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textAnswer);
            this.Controls.Add(this.labelAnswer);
            this.Controls.Add(this.textOption4);
            this.Controls.Add(this.labelOption4);
            this.Controls.Add(this.textOption3);
            this.Controls.Add(this.labelOption3);
            this.Controls.Add(this.textOption2);
            this.Controls.Add(this.labelOption2);
            this.Controls.Add(this.textOption1);
            this.Controls.Add(this.labelOption1);
            this.Controls.Add(this.textQuestion);
            this.Controls.Add(this.Question);
            this.Controls.Add(this.questionNumber);
            this.Controls.Add(this.textSet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "addQuestion";
            this.Text = "addQuestion";
            this.Load += new System.EventHandler(this.addQuestion_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textSet;
        private System.Windows.Forms.Label questionNumber;
        private System.Windows.Forms.Label Question;
        private System.Windows.Forms.TextBox textQuestion;
        private System.Windows.Forms.TextBox textOption1;
        private System.Windows.Forms.Label labelOption1;
        private System.Windows.Forms.TextBox textOption2;
        private System.Windows.Forms.Label labelOption2;
        private System.Windows.Forms.TextBox textOption3;
        private System.Windows.Forms.Label labelOption3;
        private System.Windows.Forms.TextBox textOption4;
        private System.Windows.Forms.Label labelOption4;
        private System.Windows.Forms.TextBox textAnswer;
        private System.Windows.Forms.Label labelAnswer;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
    }
}