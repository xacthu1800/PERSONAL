﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4_ltcsdl
{
    internal class stuD
    {
        public int roll_num { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public string contact_num { get; set; }
    }
}
