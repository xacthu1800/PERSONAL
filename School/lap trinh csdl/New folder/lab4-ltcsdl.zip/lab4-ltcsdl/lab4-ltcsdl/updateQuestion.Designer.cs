﻿namespace lab4_ltcsdl
{
    partial class updateQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.uComSet = new System.Windows.Forms.ComboBox();
            this.uComQuestionno = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.uTextQuestion = new System.Windows.Forms.TextBox();
            this.uTextOption4 = new System.Windows.Forms.TextBox();
            this.labelOption4 = new System.Windows.Forms.Label();
            this.uTextOption3 = new System.Windows.Forms.TextBox();
            this.labelOption3 = new System.Windows.Forms.Label();
            this.uTextOption2 = new System.Windows.Forms.TextBox();
            this.labelOption2 = new System.Windows.Forms.Label();
            this.uTextOption1 = new System.Windows.Forms.TextBox();
            this.labelOption1 = new System.Windows.Forms.Label();
            this.uTextAnswer = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.uButtonUpdate = new System.Windows.Forms.Button();
            this.uButtonReset = new System.Windows.Forms.Button();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label1.Location = new System.Drawing.Point(24, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(310, 46);
            this.label1.TabIndex = 1;
            this.label1.Text = "Update question";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label3.Location = new System.Drawing.Point(966, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Qusetion No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.Location = new System.Drawing.Point(562, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Set";
            // 
            // uComSet
            // 
            this.uComSet.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uComSet.FormattingEnabled = true;
            this.uComSet.Location = new System.Drawing.Point(567, 101);
            this.uComSet.Name = "uComSet";
            this.uComSet.Size = new System.Drawing.Size(280, 39);
            this.uComSet.TabIndex = 7;
            this.uComSet.SelectedIndexChanged += new System.EventHandler(this.uComSet_SelectedIndexChanged);
            // 
            // uComQuestionno
            // 
            this.uComQuestionno.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uComQuestionno.FormattingEnabled = true;
            this.uComQuestionno.Location = new System.Drawing.Point(971, 101);
            this.uComQuestionno.Name = "uComQuestionno";
            this.uComQuestionno.Size = new System.Drawing.Size(280, 39);
            this.uComQuestionno.TabIndex = 8;
            this.uComQuestionno.SelectedIndexChanged += new System.EventHandler(this.uComQuestionno_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label4.Location = new System.Drawing.Point(37, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(136, 32);
            this.label4.TabIndex = 9;
            this.label4.Text = "Qusetion ";
            // 
            // uTextQuestion
            // 
            this.uTextQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextQuestion.Location = new System.Drawing.Point(31, 169);
            this.uTextQuestion.Name = "uTextQuestion";
            this.uTextQuestion.Size = new System.Drawing.Size(684, 38);
            this.uTextQuestion.TabIndex = 10;
            // 
            // uTextOption4
            // 
            this.uTextOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextOption4.Location = new System.Drawing.Point(718, 447);
            this.uTextOption4.Name = "uTextOption4";
            this.uTextOption4.Size = new System.Drawing.Size(533, 38);
            this.uTextOption4.TabIndex = 22;
            // 
            // labelOption4
            // 
            this.labelOption4.AutoSize = true;
            this.labelOption4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption4.Location = new System.Drawing.Point(715, 401);
            this.labelOption4.Name = "labelOption4";
            this.labelOption4.Size = new System.Drawing.Size(122, 32);
            this.labelOption4.TabIndex = 21;
            this.labelOption4.Text = "Option 4";
            // 
            // uTextOption3
            // 
            this.uTextOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextOption3.Location = new System.Drawing.Point(79, 447);
            this.uTextOption3.Name = "uTextOption3";
            this.uTextOption3.Size = new System.Drawing.Size(522, 38);
            this.uTextOption3.TabIndex = 20;
            // 
            // labelOption3
            // 
            this.labelOption3.AutoSize = true;
            this.labelOption3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption3.Location = new System.Drawing.Point(76, 401);
            this.labelOption3.Name = "labelOption3";
            this.labelOption3.Size = new System.Drawing.Size(122, 32);
            this.labelOption3.TabIndex = 19;
            this.labelOption3.Text = "Option 3";
            // 
            // uTextOption2
            // 
            this.uTextOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextOption2.Location = new System.Drawing.Point(718, 310);
            this.uTextOption2.Name = "uTextOption2";
            this.uTextOption2.Size = new System.Drawing.Size(533, 38);
            this.uTextOption2.TabIndex = 18;
            // 
            // labelOption2
            // 
            this.labelOption2.AutoSize = true;
            this.labelOption2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption2.Location = new System.Drawing.Point(715, 256);
            this.labelOption2.Name = "labelOption2";
            this.labelOption2.Size = new System.Drawing.Size(122, 32);
            this.labelOption2.TabIndex = 17;
            this.labelOption2.Text = "Option 2";
            // 
            // uTextOption1
            // 
            this.uTextOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextOption1.Location = new System.Drawing.Point(79, 310);
            this.uTextOption1.Name = "uTextOption1";
            this.uTextOption1.Size = new System.Drawing.Size(510, 38);
            this.uTextOption1.TabIndex = 16;
            // 
            // labelOption1
            // 
            this.labelOption1.AutoSize = true;
            this.labelOption1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.labelOption1.Location = new System.Drawing.Point(76, 256);
            this.labelOption1.Name = "labelOption1";
            this.labelOption1.Size = new System.Drawing.Size(122, 32);
            this.labelOption1.TabIndex = 15;
            this.labelOption1.Text = "Option 1";
            // 
            // uTextAnswer
            // 
            this.uTextAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uTextAnswer.Location = new System.Drawing.Point(340, 551);
            this.uTextAnswer.Name = "uTextAnswer";
            this.uTextAnswer.Size = new System.Drawing.Size(576, 38);
            this.uTextAnswer.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label5.Location = new System.Drawing.Point(561, 516);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 32);
            this.label5.TabIndex = 23;
            this.label5.Text = "Answer";
            // 
            // uButtonUpdate
            // 
            this.uButtonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uButtonUpdate.Location = new System.Drawing.Point(377, 615);
            this.uButtonUpdate.Name = "uButtonUpdate";
            this.uButtonUpdate.Size = new System.Drawing.Size(181, 58);
            this.uButtonUpdate.TabIndex = 25;
            this.uButtonUpdate.Text = "Update";
            this.uButtonUpdate.UseVisualStyleBackColor = true;
            this.uButtonUpdate.Click += new System.EventHandler(this.uButtonUpdate_Click);
            // 
            // uButtonReset
            // 
            this.uButtonReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.uButtonReset.Location = new System.Drawing.Point(697, 615);
            this.uButtonReset.Name = "uButtonReset";
            this.uButtonReset.Size = new System.Drawing.Size(181, 58);
            this.uButtonReset.TabIndex = 26;
            this.uButtonReset.Text = "Reset";
            this.uButtonReset.UseVisualStyleBackColor = true;
            this.uButtonReset.Click += new System.EventHandler(this.uButtonReset_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1259, 25);
            this.toolStrip1.TabIndex = 27;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(126, 22);
            this.toolStripLabel1.Text = "AddNewQuestion";
            this.toolStripLabel1.Click += new System.EventHandler(this.toolStripLabel1_Click_1);
            // 
            // updateQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 681);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.uButtonReset);
            this.Controls.Add(this.uButtonUpdate);
            this.Controls.Add(this.uTextAnswer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.uTextOption4);
            this.Controls.Add(this.labelOption4);
            this.Controls.Add(this.uTextOption3);
            this.Controls.Add(this.labelOption3);
            this.Controls.Add(this.uTextOption2);
            this.Controls.Add(this.labelOption2);
            this.Controls.Add(this.uTextOption1);
            this.Controls.Add(this.labelOption1);
            this.Controls.Add(this.uTextQuestion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.uComQuestionno);
            this.Controls.Add(this.uComSet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "updateQuestion";
            this.Text = "updateQuestion";
            this.Load += new System.EventHandler(this.updateQuestion_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox uComSet;
        private System.Windows.Forms.ComboBox uComQuestionno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox uTextQuestion;
        private System.Windows.Forms.TextBox uTextOption4;
        private System.Windows.Forms.Label labelOption4;
        private System.Windows.Forms.TextBox uTextOption3;
        private System.Windows.Forms.Label labelOption3;
        private System.Windows.Forms.TextBox uTextOption2;
        private System.Windows.Forms.Label labelOption2;
        private System.Windows.Forms.TextBox uTextOption1;
        private System.Windows.Forms.Label labelOption1;
        private System.Windows.Forms.TextBox uTextAnswer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button uButtonUpdate;
        private System.Windows.Forms.Button uButtonReset;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
    }
}